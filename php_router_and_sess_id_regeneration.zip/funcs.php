
<?php
    
function getQueryString() {
    $qs = '';
    if (isset($_SERVER['QUERY_STRING'])) {
        $tempArr = explode('?', $_SERVER['QUERY_STRING']);
        // dd($tempArr); // array ([0] => /about)
        // http://localhost:8000/?/about
        $qs = $tempArr[0];
        // dd($qs); // 'home' or '/home'
    }
    return $qs;
}

function app($route, $callback) {
    $qs = getQueryString();

    if ($route == $qs) {
        $callback();
    }
}

function render($tpl_path, $data = null) {
    include './templates/inc/header.php';
    include './' . $tpl_path . '.php';
    include './templates/inc/footer.php';
}

function redirect($url) {
    header("Location:" . $url);
    exit;
}

function getConfData() {
                
    $file = file_get_contents("./conf.json");
    
    $data = json_decode($file, true);
    $conf_data = [];
    $conf_data['username'] = $data['username'];
    $conf_data['password'] = $data['password'];
    $conf_data['csrf_token'] = $data['csrf_token'];
    $conf_data['pass_token'] = $data['pass_token'];
    return $conf_data;
}

function escapeInput($input) {
        
    if (!empty($input)) {
        $input = trim($input);
        $input = stripslashes($input);
        $input =  htmlspecialchars($input);
        return $input;
    } 
    return null;
}

function dd($var) {
    echo '<pre>';
    print_r($var);
    echo '<pre>';
    die();
}

