<!DOCTYPE html>
<html>
    <head>
        <style>
            .navlink {
                display: inline-block;
                margin: 4px 8px;
            }
        </style>
    </head>
    <body>
        <nav>
            <a href="http://localhost:8000/" class="navlink"> Home page </a>
            <a href="?task1" class="navlink"> Second page </a>
            <a href="?task2" class="navlink"> Second page </a>
        </nav>