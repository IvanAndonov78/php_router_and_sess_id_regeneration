<form method="POST" action="?process_login" id="loginForm">
    <br>
    <label> Email: </label>
    <p> <input type="email" name="mail" class="form-txt-input" /> </p>
    <label> Password: </label>
    <p> <input type="password" name="pass" class="form-txt-input" /> </p>
    <p> 
        <input type="submit" name="sbmLoginForm" class="mybtn" id="sbmLoginBtn"/> 
        <input type="reset" name="rstLoginForm" class="mybtn"/> 
    </p>
</form>
