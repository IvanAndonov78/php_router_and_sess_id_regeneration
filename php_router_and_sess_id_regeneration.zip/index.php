<?php
// header('Access-Control-Allow-Origin: *'); // remove this on prod !
include_once './funcs.php';
// -- front controller: ---------------- 

// http://localhost:8000/
app('', function() {
	render('/templates/home_vw');
});

// http://localhost:8000/?process_login
app('process_login', function() { 

	if (isset($_POST['mail']) && isset($_POST['pass'])) {	

		$conf_data = getConfData();
  
		if ($_POST['mail'] == $conf_data['username'] && 
			$_POST['pass'] = $conf_data['password']) {
			
			session_start();
			$_SESSION['mysess'] = $conf_data['pass_token'];
			echo 'before: ' . session_id();
			session_regenerate_id();
			render('templates/second_vw');
		}
	}		
});

// http://localhost:8000/?task1
app('task1', function(){
	session_start();
	render('templates/third_vw');
});

// http://localhost:8000/?task2
app('task2', function(){
	session_start();
	render('templates/fourth_vw');
});

// https://stackoverflow.com/questions/22965067/when-and-why-i-should-use-session-regenerate-id 

