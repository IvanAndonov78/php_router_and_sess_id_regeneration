<h1> I am the SECOND page </h1>

<?php  
    if (isset($_SESSION['mysess'])) {
        echo $_SESSION['mysess'];
    }
    echo '<br><br>';

    echo 'Your session ID is: ' . session_id();
?>

<br>